package Folha.Pagamento.folha.pagamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class FolhaPagamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
