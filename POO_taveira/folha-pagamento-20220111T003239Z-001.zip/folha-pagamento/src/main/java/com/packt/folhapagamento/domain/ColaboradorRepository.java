package com.packt.folhapagamento.domain;

import org.springframework.data.repository.CrudRepository;

public interface ColaboradorRepository extends CrudRepository<Colaborador, Long>
{
	 }

