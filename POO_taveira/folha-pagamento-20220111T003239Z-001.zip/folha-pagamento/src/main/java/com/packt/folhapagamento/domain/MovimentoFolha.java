package com.packt.folhapagamento.domain;

import javax.persistence.*;

@Entity
@Table(name="MovimentoFolha")
 public class MovimentoFolha {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private String descricao;
	private float valor; 
	private TipoMovimento tipoMovimento;
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "colaborador")
	private Colaborador colaborador;
	@ManyToOne(fetch = FetchType.LAZY)
 	@JoinColumn(name = "folhaPagamento")
 	private FolhaPagamento folhaPagamento;

	public MovimentoFolha(Colaborador colaborador, String descricao, float valor, String tipoMovimento) {
		if(tipoMovimento == "P") {
		this.colaborador = colaborador;	
		this.tipoMovimento = TipoMovimento.P;
		this.descricao = descricao;	
		this.valor = valor;}else
		if(tipoMovimento == "D") {
		this.colaborador = colaborador;
		this.tipoMovimento = TipoMovimento.D;
		this.descricao = descricao;	
		this.valor = valor;
		}
	 }

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public TipoMovimento getTipoMovimento() {
		return tipoMovimento;
	}

	public void setTipoMovimento(TipoMovimento tipoMovimento) {
		this.tipoMovimento = tipoMovimento;
	}

	public Colaborador getColaborador() {
		return colaborador;
	}

	public void setColaborador(Colaborador colaborador) {
		this.colaborador = colaborador;
	 }
	
	public FolhaPagamento getFolhaPagamento() {
		return folhaPagamento;
	}


	public void setFolhaPagamento(FolhaPagamento folhaPagamento) {
		this.folhaPagamento = folhaPagamento;
	}

}