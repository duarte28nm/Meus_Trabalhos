package com.packt.folhapagamento;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.packt.folhapagamento.domain.Colaborador;
import com.packt.folhapagamento.domain.ColaboradorRepository;
import com.packt.folhapagamento.domain.FolhaPagamento;
import com.packt.folhapagamento.domain.FolhaPagamentoRepository;
import com.packt.folhapagamento.domain.MovimentoFolha;
import com.packt.folhapagamento.domain.MovimentoFolhaRepository;

@SpringBootApplication
public class FolhaPagamentoApplication {
	
	@Autowired
	private ColaboradorRepository Repository;
	
	@Autowired 
	private FolhaPagamentoRepository Repository02;
	
	@Autowired 
	private MovimentoFolhaRepository Repository03;
	 
	public static void main(String[] args) {
		SpringApplication.run(FolhaPagamentoApplication.class, args);
	}
	 @Bean
	 CommandLineRunner runner(){
		 return args -> {
			 
		 Colaborador cl01 = new Colaborador (100, "Maoel Claudino", "Av 13 de Maio, 2081", "8867-1020", "Benfica", "60020-060", "124543556-89", 4500f);
		 Colaborador cl02 = new Colaborador (200, "Carmelina da Silva", "Avenida dos Expedicionários, 1200" ,"3035-1280", "Aeroporto", "60530-020", "301789435-54", 2500f);
		 Colaborador cl03 = new Colaborador (300, "Gurmelina Castro Saraiva", "Av João Pessoa, 1020", "3235-1089", "Damas", "60330-090", "350245632-76", 3000f);
		 
		 Repository.save(cl01);
		 Repository.save(cl02);
		 Repository.save(cl03);
		 
		 MovimentoFolha movimentofolha01 = new MovimentoFolha (cl01, "Salario", 4500f, "P");
		 Repository03.save(movimentofolha01);
		 
		 MovimentoFolha movimentofolha02 = new MovimentoFolha (cl01, "Plano Saúde", 1000f, "P");
		 Repository03.save(movimentofolha02);
		 
		 MovimentoFolha movimentofolha03 = new MovimentoFolha  (cl01, "Pensão", 600f, "D");
		 Repository03.save(movimentofolha03);
		 
		 MovimentoFolha movimentofolha04 = new MovimentoFolha  (cl02, "Salario", 2500f, "P");
		 Repository03.save(movimentofolha04);
		 
		 MovimentoFolha movimentofolha05 = new MovimentoFolha  (cl02, "Gratificação", 1000f, "P");
		 Repository03.save(movimentofolha05);
		 
		 MovimentoFolha movimentofolha06 = new MovimentoFolha  (cl02, "Faltas", 1000f, "D");
		 Repository03.save(movimentofolha06);
		 
		 MovimentoFolha movimentofolha07 = new MovimentoFolha  (cl03, "Salario", 3000f, "P");
		 Repository03.save(movimentofolha07);
		 
		 MovimentoFolha movimentofolha08 = new MovimentoFolha  (cl03, "Férias", 800f, "D");
		 Repository03.save(movimentofolha08);
		 
		 MovimentoFolha movimentofolha09 = new MovimentoFolha  (cl03, "Plano Saúde", 1000f, "D");
		 Repository03.save(movimentofolha09);
			
		 FolhaPagamento fp = new FolhaPagamento (9, 2018, 2500f, 2700f);
		 Repository02.save(fp);
        
		 };
       }
	 }