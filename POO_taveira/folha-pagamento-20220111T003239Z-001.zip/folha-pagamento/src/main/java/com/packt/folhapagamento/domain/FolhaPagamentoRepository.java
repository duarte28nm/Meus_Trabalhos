package com.packt.folhapagamento.domain;
import org.springframework.data.repository.CrudRepository;

public interface FolhaPagamentoRepository extends CrudRepository<FolhaPagamento, Long>{
	 }

