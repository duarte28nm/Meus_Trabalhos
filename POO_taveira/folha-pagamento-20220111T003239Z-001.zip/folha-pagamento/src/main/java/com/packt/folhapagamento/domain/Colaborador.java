package com.packt.folhapagamento.domain;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="Colaboradores")
public class Colaborador {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private int codigo;
	private String nome;
	private String endereco;
	private String telefone;
	private String bairro;
	private String cep;
	private String cpf;
	private float salarioatual;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "folhaPagamento")
	private FolhaPagamento folhaPagamento;

	public Colaborador(int codigo, String nome, String endereco, String telefone, String bairro, String cep, String cpf,
			float salarioatual) {
		this.codigo = codigo;
		this.nome = nome;
		this.endereco = endereco;
		this.telefone = telefone;
		this.bairro = bairro;
		this.cep = cep;
		this.cpf = cpf;
		this.salarioatual = salarioatual;
	}

	public FolhaPagamento getFolhaPagamento() {
		return folhaPagamento;
	}

	public void setFolhaPagamento(FolhaPagamento folhaPagamento) {
		this.folhaPagamento = folhaPagamento;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public float getSalarioatual() {
		return salarioatual;
	}

	public void setSalarioatual(float salarioatual) {
		this.salarioatual = salarioatual;
	}

	public String CalcularSalario(FolhaPagamento folha) {
		float Salario = 0;
		float totalDescontos = 0;
		float totalProventes = 0;
		for (MovimentoFolha movimento : folha.getMovimentos()) {
			if (movimento.getColaborador().getCodigo() == this.codigo) {
				if (movimento.getDescricao() == "Salario") {
					Salario += movimento.getValor();
				} else
					;
				if (movimento.getTipoMovimento() == TipoMovimento.P) {
					totalProventes += movimento.getValor();
				} else
					;
				if (movimento.getTipoMovimento() == TipoMovimento.D) {
					totalDescontos += movimento.getValor();
				}
			}
		}
		System.out.println("");
		String retorno = String.format(
				"Codigo:%4d Nome:%s\n Salario:%,10.2f TotalProvente:%,10.2f TotalDescontos:%,11.2f ValorLiquidoaReceber: %,10.2f\n",
				this.codigo, this.nome, Salario, totalProventes, totalDescontos,
				(Salario + totalProventes - totalDescontos));
		return retorno;
	}
}