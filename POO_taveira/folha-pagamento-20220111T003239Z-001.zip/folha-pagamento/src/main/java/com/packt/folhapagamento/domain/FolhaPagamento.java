package com.packt.folhapagamento.domain;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Entity
@Table(name="FolhaPagamento")
 public class FolhaPagamento {
	@Id
 	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
 	private int mes;
 	private float totalDesconto;
 	private float totalProvente;
 	private int ano;
 	@OneToMany(cascade = CascadeType.ALL, mappedBy="folhaPagamento")
 	private List<MovimentoFolha> movimentos;
 	@OneToMany(cascade = CascadeType.ALL, mappedBy="folhaPagamento")
 	private List<Colaborador> colaboradores;

 public FolhaPagamento(int mes, int ano, float totalDesconto, float totalProvento) {
	this.mes = mes;
	this.ano = ano;
	this.totalDesconto = totalDesconto;
	this.totalProvente = totalProvento;
	this.movimentos = new ArrayList<MovimentoFolha>();
    this.colaboradores = new ArrayList<Colaborador>();
}

 public List<Colaborador> getColaboradores() {
		return colaboradores;
	}
 
public int getMes() {
	return mes;
}

public void setMes(int mes) {
	this.mes = mes;
}

public float getTotalDesconto() {
	return totalDesconto;
}

public void setTotalDesconto(float totalDesconto) {
	this.totalDesconto = totalDesconto;
}

public float getTotalProvente() {
	return totalProvente;
}

public void setTotalProvente(float totalProvente) {
	this.totalProvente = totalProvente;
}

public int getAno() {
	return ano;
}

public void setAno(int ano) {
	this.ano = ano;
}

public List<MovimentoFolha> getMovimentos() {
	return movimentos;
}

public void InserirMovimento(MovimentoFolha item) {
	this.movimentos.add(item);
 }

public void InserirColaborador(Colaborador colaborador) {
	this.colaboradores.add(colaborador);
}

public String CalcularFolha() {
    float Salarios = 0;
	float Descontos = 0;
	float Proventes = 0;
	float ValorReceber = 0;
	for(MovimentoFolha item: this.movimentos) {
	if(item.getDescricao() == "Salario") {
	 Salarios+=item.getValor();	
	}else;
	if(item.getTipoMovimento() == TipoMovimento.P) {
		Proventes+=item.getValor();
	}else;
    if(item.getTipoMovimento() == TipoMovimento.D) {
	   Descontos+=item.getValor();
    }
  }
ValorReceber = Salarios + Proventes;
ValorReceber -= Descontos;
String retorno = String.format("Total de Salario =%,10.2f Total de Proventes=%,10.2f Total de Descontos%,10.2f Valor a Receber=,10.2f", Salarios,Proventes,Descontos,ValorReceber);
return retorno;
 }
}