package com.packt.faturamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaturamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
