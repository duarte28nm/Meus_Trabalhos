package com.packt.faturamento.domain;

public enum TipoCliente {
	PESSOAFISICA, PESSOAJURIDICA;
	
}
