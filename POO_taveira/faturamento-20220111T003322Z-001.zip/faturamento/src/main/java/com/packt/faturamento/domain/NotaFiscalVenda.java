package com.packt.faturamento.domain;

import javax.persistence.*;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

@Entity
@Table(name = "Notas_Fiscais")

public class NotaFiscalVenda {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private int codigo;
	private String data;
	public float valorNota;
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Cliente")
	private Cliente cliente;
	@OneToMany(cascade = CascadeType.ALL, mappedBy="notaFiscal")
	private List<ItemNotaFiscal> itens;
	
	NotaFiscalVenda(){
	}
	
	public NotaFiscalVenda(int codigo, String data, Cliente cliente){
		this.codigo = codigo;
		this.data = data;
		this.cliente = cliente;
		this.itens = new LinkedList<ItemNotaFiscal>();
	}
	
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	public String getData() {
		return data;
	}
	
	public void setData(String data) {
		this.data = data;
	}
	
	public float getValorNota() {
		return valorNota;
	}
	
	public void setValorNota(float valorNota) {
		this.valorNota = valorNota;
	}
	
	public List<ItemNotaFiscal> getItens() {
		return itens;
	}
	
	public void seItens(List<ItemNotaFiscal> itens) {
		this.itens = itens;
	}
	
	public void criarItemNotaFiscal(ItemNotaFiscal item) {
		itens.add(item);
	}
	
	public BigDecimal calcularValor() {
		for (ItemNotaFiscal item : itens) {
			valorNota = (float) (item.valorItemNF() + valorNota);
		}
		return BigDecimal.valueOf(valorNota);
	}

}