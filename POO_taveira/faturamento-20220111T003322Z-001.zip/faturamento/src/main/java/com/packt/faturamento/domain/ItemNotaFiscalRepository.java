package com.packt.faturamento.domain;

import org.springframework.data.repository.CrudRepository;

public interface ItemNotaFiscalRepository extends CrudRepository <ItemNotaFiscal, Long> {
	 }
