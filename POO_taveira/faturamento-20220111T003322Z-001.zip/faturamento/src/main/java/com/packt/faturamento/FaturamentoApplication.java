package com.packt.faturamento;

import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.packt.faturamento.domain.Cliente;
import com.packt.faturamento.domain.ClienteRepository;
import com.packt.faturamento.domain.ItemNotaFiscal;
import com.packt.faturamento.domain.ItemNotaFiscalRepository;
import com.packt.faturamento.domain.NotaFiscalVenda;
import com.packt.faturamento.domain.NotaFiscalVendaRepository;
import com.packt.faturamento.domain.Produto;
import com.packt.faturamento.domain.ProdutoRepository;

@SpringBootApplication
public class FaturamentoApplication {
	@Autowired
	private ProdutoRepository prepository;
	
	@Autowired
	private ItemNotaFiscalRepository itfrepository;
	
	@Autowired
	private ClienteRepository crepository;
	
	@Autowired
	private NotaFiscalVendaRepository nfvrepository;
	
	public static void main(String[] args) {
		SpringApplication.run(FaturamentoApplication.class, args);
	}
	@Bean
	CommandLineRunner runner(){
		 return args -> {
			 Produto P1 = new Produto(01, "Café", new BigDecimal("4.60"));
			 Cliente C1 = new Cliente(111, "Maurício", "123.456.678-90", "Pessoa Física");
			 prepository.save(P1);
			 prepository.save(new Produto(02, "Milho", new BigDecimal("3.60")));
			 prepository.save(new Produto(03, "Chocolate", new BigDecimal("10.0")));
			 crepository.save(C1);
			 NotaFiscalVenda NF1 = new NotaFiscalVenda(57, "11/11/2019", C1);
			 ItemNotaFiscal INF1 = new ItemNotaFiscal(01, 04, new BigDecimal("18.40"), P1, NF1);
			 NF1.criarItemNotaFiscal(INF1);
			 nfvrepository.save(NF1);
			 itfrepository.save(INF1);
		 };
	}
}
