package com.packt.faturamento.domain;

import javax.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "ItemNotaFiscal")
public class ItemNotaFiscal {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private int numero;
	private int quantidade;
	private BigDecimal valor;
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Produto")
	private Produto produto;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NotaFiscalVenda")
	private NotaFiscalVenda notaFiscal;
	
	ItemNotaFiscal(){
	}
	
	public ItemNotaFiscal(int numero, int quantidade, BigDecimal valor, Produto produto, NotaFiscalVenda notaFiscal){
		this.numero = numero;
		this.quantidade = quantidade;
		this.valor = valor;
		this.produto = produto;
		this.notaFiscal = notaFiscal;
	}
	
	public NotaFiscalVenda getNotaFiscal() {
		return notaFiscal;
	}

	public void setNotaFiscal(NotaFiscalVenda notaFiscal) {
		this.notaFiscal = notaFiscal;
	}

	public Produto getProduto() {
		return produto;
	}
	
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	
	public int getNumero() {
		return numero;
	}
	
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	public int getQuantidade() {
		return quantidade;
	}
	
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	public BigDecimal getValor() {
		return valor;
	}
	
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	
	public double valorItemNF() {
		return valor.doubleValue();
	}
	
}