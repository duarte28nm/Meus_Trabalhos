package com.packt.faturamento.domain;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Table(name = "Clientes")
public class Cliente {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private int codigo;
	private String nome;
	private String cnpjcpf;
	private TipoCliente tipoCliente;
	
	Cliente(){
	}
	
	public Cliente(int codigo, String nome, String cnpjcpf, String tipoCliente){
		if (tipoCliente == "Pessoa Jurídica") {
			this.codigo = codigo;
			this.nome = nome;
			this.cnpjcpf = cnpjcpf;
			this.tipoCliente = TipoCliente.PESSOAJURIDICA;
		}
		else if (tipoCliente == "Pessoa Física") {
			this.codigo = codigo;
			this.nome = nome;
			this.cnpjcpf = cnpjcpf;
			this.tipoCliente = TipoCliente.PESSOAFISICA;
		}
	}

	public TipoCliente getTipoCliente() {
		return tipoCliente;
	}

	public void setTipoCliente(TipoCliente tipoCliente) {
		this.tipoCliente = tipoCliente;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCnpjcpf() {
		return cnpjcpf;
	}

	public void setCnpjcpf(String cnpjcpf) {
		this.cnpjcpf = cnpjcpf;
	}

}
