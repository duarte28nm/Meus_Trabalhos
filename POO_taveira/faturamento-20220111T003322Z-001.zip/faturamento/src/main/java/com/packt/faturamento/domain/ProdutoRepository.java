package com.packt.faturamento.domain;
	
import org.springframework.data.repository.CrudRepository;

public interface ProdutoRepository extends CrudRepository <Produto, Long> {
	 }