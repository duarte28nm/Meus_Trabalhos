package com.packt.faturamento.domain;

import org.springframework.data.repository.CrudRepository;

public interface NotaFiscalVendaRepository extends CrudRepository <NotaFiscalVenda, Long> {
	 }