package com.packt.revendas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
