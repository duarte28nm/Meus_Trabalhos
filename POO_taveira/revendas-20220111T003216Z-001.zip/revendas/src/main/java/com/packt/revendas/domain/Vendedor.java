package com.packt.revendas.domain;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.List;
import javax.persistence.*;
@Entity
@Table(name = "vendedor_tbl")
public class Vendedor{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	  private Integer codigo;
	  private String nome;
	  private float comissao;
	  @OneToMany(cascade=CascadeType.ALL,mappedBy= "vendedor")
	  private List<PedidoVenda> pedidos;
	   public Vendedor(Integer codigo,String nome,float comissao,List<PedidoVenda> pedidos){
	      this.codigo=codigo;
	      this.nome=nome;
	      this.comissao=comissao;
	      this.pedidos=pedidos;
	   }
	   public Integer getCodigo(){
	      return codigo;
	   }
	   public void setCodigo(Integer Codigo){
	      this.codigo=codigo;
	   }
	   public String getNome(){
	      return nome; 
	   }
	   public void setNome(String nome){
	      this.nome=nome;
	   }
	   public float getComissao(){
	      return comissao;
	   }

	   public void setComissao(float Comissao){
	      this.comissao=comissao;
	   }
	public List<PedidoVenda> getPedidos() {
		return pedidos;
	}
	public void setPedidos(List<PedidoVenda> pedidos) {
		this.pedidos = pedidos;
	}
	}


