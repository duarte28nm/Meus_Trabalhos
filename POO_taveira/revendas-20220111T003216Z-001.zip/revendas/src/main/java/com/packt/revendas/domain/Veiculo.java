package com.packt.revendas.domain;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
@Entity
@Table(name="veiculo_tbl")
public class Veiculo{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	  private Integer codigo;
	  private String descricao;
	  private float valor;
	  @OneToOne(fetch = FetchType.LAZY)
	  @JoinColumn(name = "veiculo")
	  private PedidoVenda pedidos;
	  public PedidoVenda getPedidos() {
		return pedidos;
	}
	public void setPedidos(PedidoVenda pedidos) {
		this.pedidos = pedidos;
	}
	public Veiculo(Integer codigo,String descricao,float valor){
	    this.codigo=codigo;
	    this.descricao=descricao;
	    this.valor=valor;
	  }
	  public Integer getCodigo(){
	    return codigo;
	  }
	  public void setCodigo(Integer codigo){
	    this.codigo=codigo;
	  }
	  public String getDescricao(){
	    return descricao;
	  }
	  public void setDescricao(String descricao ){
	    this.descricao=descricao;
	  }
	  public float getValor(){
	    return valor;
	  }
	  public void setValor(float valor){
	  this.valor=valor;
	  }
	}
