package com.packt.revendas.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.*;

@Entity
@Table(name = "cliente_tbl")
public class Cliente {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private Integer codigo;

	private String nome;

	private int tipoCliente;
	@OneToMany(cascade=CascadeType.ALL,mappedBy= "cliente")
	private List<PedidoVenda> pedidos;

	public List<PedidoVenda> getPedidos() {
		return pedidos;
	}

	public void setPedidos(List<PedidoVenda> pedidos) {
		this.pedidos = pedidos;
	}

	public Cliente(Integer codigo, String nome, int tipoCliente) {
		this.codigo = codigo;
		this.nome = nome;
		this.tipoCliente = tipoCliente;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer Codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getTipoCliente() {
		return tipoCliente;
	}

	public void setTipoCliente(int tipoCliente) {
		this.tipoCliente = tipoCliente;
	}
}