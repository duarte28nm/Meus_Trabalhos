package com.packt.revendas.domain;

import org.springframework.data.repository.CrudRepository;
public interface PedidoVendaRepository extends CrudRepository <PedidoVenda, Long> {
}  