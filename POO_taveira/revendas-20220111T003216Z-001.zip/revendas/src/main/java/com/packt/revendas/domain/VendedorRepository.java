package com.packt.revendas.domain;

import org.springframework.data.repository.CrudRepository;
public interface VendedorRepository extends CrudRepository <Vendedor, Long> {
}  