package com.packt.revendas.domain;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
@Entity
@Table(name="itempedido_tbl")
public class ItemPedido{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private Integer sequencial;
	private String descricao;
	private Integer quantidade;
	private float valor;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "pedidovenda")
	private PedidoVenda pedidovenda;
	   public PedidoVenda getPedidovenda() {
		return pedidovenda;
	}
	public void setPedidovenda(PedidoVenda pedidovenda) {
		this.pedidovenda = pedidovenda;
	}
	public ItemPedido (Integer sequencial,String descricao,Integer quantidade,float valor){
	      this.sequencial=sequencial;
	      this.descricao=descricao;
	      this.quantidade=quantidade;
	      this.valor=valor;
	   }
	   public Integer getSequencial(){
	      return sequencial;
	   }
	   public void setSequencial(Integer sequencial){
	      this.sequencial=sequencial;
	   }
	   public String getDescricao(){
	      return descricao;
	   }
	   public void setDescricao(String descricao ){
	      this.descricao=descricao;
	   }
	   public Integer getQuantidade(){
	      return quantidade;
	   }
	   public void setQuantidade(Integer quantidade){
	      this.quantidade=quantidade;
	   }
	   public float getValor(){
	      return valor;
	   }
	   public void setValor(float valor){
	      this.valor=valor;
	   }

	}
