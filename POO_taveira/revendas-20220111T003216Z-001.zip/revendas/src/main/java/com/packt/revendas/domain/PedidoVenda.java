package com.packt.revendas.domain;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
@Entity
@Table(name="pedidovenda_tbl")
  public class PedidoVenda{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private String codigo;
	private Date data;
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "veiculo")
	private Veiculo veiculo;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "vendedor")
	private Vendedor vendedor;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cliente")
	private Cliente cliente;
	@OneToMany(cascade=CascadeType.ALL,mappedBy= "pedidovenda")
	private List <ItemPedido> itens;
     public PedidoVenda(){
     }
     public PedidoVenda(String codigo, Date data,Veiculo veiculo, Vendedor vendedor,Cliente cliente,List <ItemPedido> itens){
       this.codigo=codigo;
       this.data=data;
       this.veiculo=veiculo;
       this.vendedor=vendedor;
       this.cliente=cliente;
       this.itens=itens;}
     public String getCodigo(){
       return codigo;
     }
     public void setCodigo(String codigo){
       this.codigo=codigo;
     }
     public Date getData(){
       return data;
     }
     public void setData(Date data){
       this.data=data;
     }
     public Veiculo getVeiculo(){
       return veiculo;
     }
     public void setVeiculo(Veiculo veiculo){
       this.veiculo=veiculo;
     }
     public Vendedor getVendedor(){
       return vendedor;
     }
     public void setVendedor(Vendedor vendedor){
       this.vendedor=vendedor;
     }
     public Cliente getCliente(){
       return cliente;
     }
     public void setCliente(Cliente cliente){
       this.cliente=cliente;
     }
     public List<ItemPedido> getItens(){
       return itens;
     }
     public void setItens(List<ItemPedido> itens){
       this.itens=itens;
     }
     public void inserirItemPedido(ItemPedido item){
       this.itens.add(item);
     }
     public float calcularPedido(){
       float valorPedido=0;
       for( ItemPedido itemp : this.itens){
          valorPedido = valorPedido + (itemp.getQuantidade()*itemp.getValor());
       }
       return valorPedido;
      }
}
