package com.packt.revendas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.packt.revendas.domain.Cliente;
import com.packt.revendas.domain.ClienteRepository;
import com.packt.revendas.domain.Vendedor;
import com.packt.revendas.domain.VendedorRepository;
import com.packt.revendas.domain.Veiculo;
import com.packt.revendas.domain.VeiculoRepository;
import com.packt.revendas.domain.ItemPedido;
import com.packt.revendas.domain.ItemPedidoRepository;
import com.packt.revendas.domain.PedidoVenda;
import com.packt.revendas.domain.PedidoVendaRepository;

@SpringBootApplication
public class RevendasApplication {
	@Autowired
	private ClienteRepository repository1;
	@Autowired
	private VendedorRepository repository2;
	@Autowired
	private VeiculoRepository repository3;
	@Autowired
    private ItemPedidoRepository repository4;
	@Autowired
	private PedidoVendaRepository repository5;

	public static void main(String[] args) {
		SpringApplication.run(RevendasApplication.class, args);
	}
	@Bean
	CommandLineRunner runner(){

	return args -> {
	
	};
	}

}
